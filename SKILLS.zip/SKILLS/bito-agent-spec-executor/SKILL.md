---
name: bito-agent-spec-executor
description: >-
  Execute a single workstream agent spec produced by bito-plan-to-agent-spec.
  Takes the original implementation plan (for architectural context) and one
  workstream agent-spec file, then implements it step by step with verification
  gates after each logical unit. After implementation, runs a two-stage review:
  spec compliance (did we build what the spec says?) and code quality (race
  conditions, error handling, security, test coverage). Works with any AI coding
  platform that supports skill-based execution.
  Triggers: 'execute this agent spec', 'implement this workstream spec',
  'run this agent spec', 'implement workstream', 'execute workstream spec',
  'build from this agent spec', 'implement this spec file'.
  Also trigger when the user provides a .agent-spec.md file and wants it
  implemented.
---

> **Requires:** The user must provide TWO inputs: (1) the original implementation
> plan, and (2) one workstream agent-spec file (typically from
> `bito-plan-to-agent-spec`, but any spec following the same format works).
>
> **Codebase access — use all available sources, verify with local:** Use both
> local codebase access and BitoAIArchitect MCP when available. AI Architect
> provides pre-analyzed data (`coding_standards`, `implementation_patterns`,
> `architectural_patterns`) and code-level tools (`getCode`, `searchCode`,
> `searchSymbols`). Pre-analyzed fields may be incomplete if indexing is in
> progress — treat them as accelerators, not the only source. Always fall back
> to AI Architect code-level tools or local reads when pre-analyzed data is
> empty. Local code is always the source of truth for file contents. All AI
> Architect tool calls require `purposeType` (use `code_generation` for this
> skill) and `purpose` parameters.
>
> **Platform-agnostic:** This skill works on any agentic platform that supports
> skill-based execution. It uses generic instructions (create file, run command,
> read file) rather than platform-specific tool calls. Where the skill says "run
> the verification command," use whatever command execution the host platform
> provides. Where it says "create the branch," use the platform's branching or
> isolation mechanism.

> **Customizable:** The review checklists are in `references/review-checklists.md`.
> Clients can replace or extend these to match their team's standards.

# Agent Spec Executor: Implement a Workstream from an Agent Spec

## Purpose

Take a single workstream agent spec and implement it — file by file, step by
step, with verification after each logical unit. Then review the implementation
for both spec compliance and code quality.

**This is the last mile: from detailed coding instructions to working code.**

### What this skill does

1. **Loads context** — reads the original plan (for the "why"), the agent spec
   (for the "how"), and the pattern exemplar files referenced in the spec
2. **Implements autonomously, step by step** — creates/modifies files following
   each step in the spec in a single pass, running verification gates after
   each logical unit, without pausing for user confirmation between steps
3. **Reviews the result** — two-stage review checking spec compliance and code
   quality before declaring the workstream complete

### What this skill does NOT do

- **Explore the codebase open-endedly.** The agent-spec already front-loaded all
  discovery. This skill reads known files, not searches for unknown ones.
- **Make architectural decisions.** Those were made in the plan and encoded in the
  spec. This skill follows instructions.
- **Implement multiple workstreams.** One spec per session. Parallel execution is
  handled by running multiple sessions (one per workstream).

### How this differs from other skills

- **plan-to-agent-spec** → produces the spec. This skill *consumes* it.
- **feature-plan** → plans what to build. This skill *builds* what was planned.
- **scope-to-plan / epic-to-plan** → architectural planning. This skill is
  pure execution.

---

## Valid Workflow (State Machine)

```mermaid
flowchart TB
start["START\nReceive Plan + Agent Spec"]
phase1["Phase 1\nContext Loading\n+ Ambiguity Pre-Scan"]
phase2["Phase 2\nBranch Setup &\nBaseline Verification"]
phase3["Phase 3\nStep-by-Step Implementation\nWith Verification Gates"]
gate{"Verification\nGate Failed?"}
fix["Fix (max 3 retries)\nRollback if stuck"]
phase4["Phase 4\nSpec Compliance Review\n(Adversarial)"]
phase5["Phase 5\nCode Quality Review"]
phase6["Phase 6\nFinal Report"]
done["DONE\nWorkstream Implemented"]

start --> phase1
phase1 --> phase2
phase2 --> phase3
phase3 --> gate
gate -- "yes (≤3 retries)" --> fix
fix --> gate
gate -- no --> phase4
phase4 --> phase5
phase5 --> phase6
phase6 --> done
```

The ONLY valid terminal state is `DONE`. Do not skip reviews.

---

## Anti-Rationalization Table

| Rationalization | Why It's Wrong |
|---|---|
| "The spec is clear enough, I don't need to read the pattern files" | Pattern files contain structural details (decorators, error handling, initialization patterns) that the spec references but doesn't inline. Skipping them means guessing at conventions. |
| "I'll read the plan later if I need it" | The plan contains architectural intent and cross-cutting concerns that inform micro-decisions during implementation. Load it first. |
| "The verification gate is just compilation — I'll check at the end" | Small errors compound. A wrong import in Step 2 causes cascading failures in Steps 3-8. Verify early, fix immediately. |
| "The review is redundant — I just followed the spec" | Following instructions and verifying you followed them correctly are different activities. The review catches drift, omissions, and quality issues the spec couldn't anticipate. |
| "I can skip the code quality review since the spec was detailed" | The spec dictates structure, not every quality aspect. Race conditions, resource leaks, and edge cases emerge from the specific code written, not from the spec's instructions. |
| "My tests pass so the implementation is correct" | Tests you wrote may be tautological — asserting what the code does rather than what the spec requires. Always compare test assertions against the spec's acceptance proof and domain invariants. |
| "I'll just retry the failing gate — it'll work this time" | Retrying the same approach wastes context. After 3 failures, rollback to the last green state and re-approach from scratch with the error message as new context. |
| "The user might want to review after the first step / first unit / first file" | The spec's ordering and verification gates are the review mechanism. Stopping mid-spec to ask "continue?" discards the atomic-workstream contract, fragments the branch's change history, and pushes coordination work back to the user. Phase 6's report is where the user reviews — not between steps. |

---

## Phase 1: Context Loading

Load all context before writing any code. This phase is pure reading — no
file creation or modification.

### 1.1 Read the Implementation Plan

Read the original implementation plan document. Extract and hold in context:

- **Selected approach** — the architectural strategy constraining all decisions
- **Cross-cutting concerns** — rollback strategy, feature flags, observability,
  error handling patterns, logging conventions
- **Schema definitions** — data schemas, API contracts, data models
- **This workstream's place in the larger system** — what comes before and after

The plan gives you the "why" behind the spec's instructions. When the spec
says "use a transaction on the create function," the plan explains why (single
atomic operation across multiple related entities).

### 1.2 Read the Agent Spec

Read the workstream agent-spec file. Extract:

- **Codebase constraints** — the always/never rules from the spec's preamble (Section 0)
- **Dependency contract** — what this workstream assumes exists (Assumes), what it
  creates (Provides), and what files it exclusively owns (Owns)
- **Branch name** — from the spec's header
- **All steps** — the ordered implementation sequence
- **All verification gates** — what to run and when
- **Pattern file references** — every file path mentioned as "follow the pattern in..."

### 1.3 Read Pattern Exemplar Files

This is the targeted codebase reading step. For each file referenced as a
pattern exemplar in the spec, read it and understand:

- **Structure** — file organization, function/method ordering, field declarations
- **Annotations / decorators / attributes** — exact metadata used, their parameters
- **Initialization / injection pattern** — how dependencies are provided
- **Error handling** — how exceptions are caught, wrapped, and propagated
- **Test patterns** — if the pattern file has a corresponding test, read that too

Read these files locally when the repo is checked out — this gives the latest
version. If a pattern file is in a different repo without local access, use
AI Architect's `getCode` to read it. This is NOT open-ended exploration — you
are reading specific, known files that the spec already identified.

### 1.4 Read Existing Files to Be Modified

If any step in the spec says "Modify `existing-file`," read that file
now so you understand its current state before making changes.

### 1.5 Ambiguity Pre-Scan

Before writing any code, scan all steps in the spec for gaps or ambiguity:

- Are any steps vague about what to implement? (e.g., "add appropriate validation"
  without specifying what to validate)
- Are there missing pattern references for non-trivial steps?
- Do any steps conflict with each other or with the plan?
- Are domain invariants missing for steps that clearly involve business logic?

If ambiguities are found: refer to the plan's selected approach and the pattern
exemplar to resolve them. Document each resolution with the reasoning. If a gap
is too large to resolve confidently, flag it to the user before starting
implementation — catching it now is far cheaper than discovering it in Phase 4.

### 1.6 Context Verification

Before proceeding, confirm:
- [ ] You can state the selected architectural approach in one sentence
- [ ] You know the branch name to create
- [ ] You've read every pattern file referenced in the spec
- [ ] You've read every existing file that will be modified
- [ ] You understand the dependency contract (what's assumed, what you'll provide)
- [ ] You've scanned for ambiguities and resolved or flagged them all
- [ ] You've read the codebase constraints from the spec preamble

---

## Phase 2: Branch Setup & Baseline Verification

### 2.1 Create the Branch

Follow the spec's Setup section (Section 2). Create the branch using the
exact branch name from the spec header. The naming convention
(`{ticket-id}/ws{N}-{slug}`) was established by the plan-to-agent-spec skill
and must be consistent across all workstream branches.

Use whatever branching mechanism the host platform provides — `git checkout -b`
for local CLI environments, the platform's built-in branch creation tool, or
a worktree for platforms that support it. The key requirement is code isolation:
this workstream's changes must not affect other workstreams in progress.

### 2.2 Verify Baseline

Run the spec's baseline verification commands (from the spec's Section 2.2).
Use whatever command execution mechanism the host platform provides — shell,
terminal tool, or built-in run command.

Both should pass. If they fail:
- **Report the specific failures to the user** with the error output.
- **Ask the user whether to proceed.** Some repos have known flaky tests or
  pre-existing issues unrelated to this workstream. The user may choose to
  proceed with the known failures as a baseline.
- If the user approves, record the pre-existing failures so they can be
  excluded from this workstream's regression check in Phase 4.
- Do NOT silently proceed past baseline failures — always surface them first.

---

## Phase 3: Step-by-Step Implementation

Execute each step from the spec's Section 3 (Implementation Steps) in order.

### Execution Rules

1. **Execute autonomously end-to-end.** Once Phase 2's baseline passes, proceed
   through every step in the spec as a single atomic workstream. Successful
   completion of one step is never a reason to pause and ask the user whether
   to continue — immediately begin the next step. The ONLY valid reasons to
   interrupt implementation are:
   - A verification gate that still fails after the retry protocol in rule 5
     (rollback path)
   - A spec ambiguity that cannot be resolved from the plan, pattern files, or
     codebase constraints
   - A dependency-contract violation (something in "Assumes" is missing AND
     cannot be safely stubbed) that blocks the remaining steps
   - An action that would require modifying files outside the "Owns" boundary

   Completion is defined by Phase 6's final report. If the host platform
   surfaces permission prompts for in-scope actions (file writes within Owns,
   verification commands from the spec), approve them without escalating to
   the user. "All steps of the spec" means exactly that — whether the spec
   contains 3 steps or 30, they are executed in one pass.

2. **Preserve step ordering.** Complete step N before starting step N+1, and
   do not reorder or parallelize steps. Ordering is a correctness constraint
   (each step builds on the prior), not a pacing mechanism — this rule is
   about *sequence*, not about pausing. Rule 1 governs continuity.

3. **Follow the pattern, adapt the content.** When the spec says "follow the
   pattern in `path/to/existing_service`," replicate the structural conventions
   (decorators, dependency wiring, error handling) but with the new content
   specified in the step.

4. **Handle Delete actions.** When a step's action is Delete: remove the file,
   then check the step's ripple risk list (if any) for files that imported or
   referenced the deleted file. If those files are within this workstream's Owns
   boundary, update them to remove the reference. Run the verification gate to
   confirm nothing still depends on the deleted file.

5. **Run verification gates.** After each step (or group of related steps)
   that has a verification gate, run it immediately. If it fails:
   - Read the error output carefully
   - Fix the issue in the file(s) just created/modified
   - Re-run the gate
   - **Retry cap**: Maximum 3 attempts per gate. If it still fails after 3
     attempts, you are likely repeating the same mistake. Halt forward progress
     on this step only (not the whole spec), undo the
     current step's changes (revert files to their state before this step),
     re-read the spec step and the error message together, and re-attempt
     the step from scratch.
   - If the fix requires a small, targeted change to a file from a prior step
     (e.g., fixing a typo in a type name), make the minimal fix. Do NOT
     restructure or refactor prior steps — that causes cascading changes.
   - Do NOT proceed until the gate passes OR the retry protocol above is
     fully exhausted (3 attempts + rollback + one re-attempt from scratch).
     In the exhausted case, document the failure in the final report and
     continue to the next step — do not escalate to the user mid-spec.

6. **Respect the dependency contract.** The spec's "Assumes" section lists
   things that should exist but may be in a parallel branch. If your code
   references something from the Assumes list and it doesn't exist locally,
   that's expected — create a minimal stub or interface if needed for the
   build to pass, but do NOT implement the dependency. Add a comment
   (using the project's comment syntax):
   `Provided by WS{N} — stub for build`

7. **Honor "Key decisions" callouts.** When a step lists architectural decisions
   from the plan, follow them exactly. These are not suggestions — they're
   constraints that keep this workstream consistent with the rest of the system.

8. **Don't add what the spec doesn't ask for.** If the spec doesn't mention
   logging for a particular function, don't add it. If the spec doesn't ask for
   a particular validation, don't add it. Over-building creates inconsistency
   with other workstreams. The review phase will flag genuine omissions.

9. **Re-anchor before each step.** Before starting each step, re-read:
   (a) the step's instructions, (b) its domain invariants (business rules the
   pattern doesn't encode), (c) its "Must NOT" negative criteria, and (d) the
   context snapshot (if present, for steps 6+). Agent quality degrades as
   context accumulates — re-anchoring prevents contradicting earlier decisions.

10. **Respect codebase constraints.** The spec's preamble (Section 0) lists
   always/never rules for the codebase. Apply them in every file you create or
   modify. These are not suggestions — they're enforced by linters and CI.

11. **Honor "Do not modify" and "Owns" boundaries.** Only touch files listed in
    the spec's "Owns" section. Never modify files outside this workstream's
    ownership boundary, even if it seems helpful. Other parallel workstreams
    own those files.

12. **Check ripple risk on Modify steps.** When the spec lists a ripple risk
    (files that depend on what you're changing), verify those files still work
    after your change. If they need updates and are within this workstream's
    Owns boundary, update them. If they're outside, note the breakage in the
    final report.

### Handling Unexpected Issues

If during implementation you encounter something the spec didn't anticipate:

- **Missing import / dependency**: Check if it's in the Assumes contract. If
  yes, stub it. If not, check the pattern exemplar — it likely has the same
  dependency. Use its import.
- **Build error from existing code**: This is a baseline issue, not your
  workstream's problem. Note it and work around it if possible.
- **Ambiguity in the spec**: Refer to the pattern exemplar file. Do what the
  pattern does. If the pattern doesn't cover this case, refer to the original
  plan's selected approach and make the choice most consistent with it.
  Document the decision with a code comment: `Spec ambiguity: chose X because pattern uses X`
- **Spec seems wrong**: If a step asks you to do something that would clearly
  break the build or conflict with the plan, note it and skip to the next
  step. Report in the final review.

---

## Phase 4: Spec Compliance Review

After all implementation steps are complete, review the work against the spec.

**Adopt an adversarial mindset.** You just wrote this code — your default is to
believe it's correct. Fight that instinct. Re-read the actual files you created
and compare them against what the spec literally says, not what you remember
writing. The purpose of this phase is to catch drift between what the spec
asked for and what was actually implemented. Early steps are especially at risk
— they were written longest ago and may have been partially overwritten by later
changes.

### 4.1 Step-by-Step Verification

For each step in the spec:

1. **File exists at the specified path?** Open it and confirm.
2. **Content matches what the spec asked for?** Check fields, functions,
   types — not just that the file exists, but that it contains what was
   specified. Compare against the spec text, not your memory.
3. **Domain invariants respected?** If the step listed domain invariants
   (business rules), verify the code enforces them. Pattern compliance alone
   is not enough — structurally correct code can violate domain rules.
4. **"Must NOT" criteria honored?** If the step listed negative criteria,
   verify none of them are violated. Look specifically for silent error
   suppression (try/catch that swallows errors and returns defaults).
5. **Pattern was followed?** Compare structural elements (decorators,
   initialization style, error handling) against the pattern exemplar.
6. **Verification gate passed?** Re-run the gate now to confirm it still
   passes after all subsequent steps have landed (later steps can regress
   earlier ones).

### 4.2 Contract Verification

Check the "Provides" section of the dependency contract:

- Every file listed in "Provides → Files created" exists at the specified path
- Every data entity listed (if applicable) has the correct schema
- Every API endpoint listed (if applicable) is implemented and routable
- Interface contracts match what downstream workstreams expect

### 4.3 Cross-Cutting Concerns

Check against the plan's cross-cutting concerns:

- **Feature flags**: If the plan specifies a feature flag for this workstream,
  is it implemented? Is the code gated behind it?
- **Observability**: Does the implementation include the logging/metrics the
  plan calls for?
- **Error handling**: Do external calls (database, API, network) have proper error
  handling consistent with the plan's patterns?
- **Rollback**: Could this workstream's changes be rolled back using the
  plan's rollback strategy?

### 4.4 Completeness Check

- [ ] Every step in the spec was executed (or explicitly skipped with a reason)
- [ ] All verification gates pass
- [ ] The Provides contract is fulfilled
- [ ] Only files in the "Owns" section were created or modified — no out-of-scope changes
- [ ] No TODO/FIXME/HACK comments left (unless the plan explicitly defers something)
- [ ] New code follows existing code style (indentation, naming, import ordering)

Report any spec compliance issues found. If issues are minor (missing decorator,
wrong field name), fix them now. If issues are structural (wrong approach,
missing component), report them — they may indicate a spec problem.

---

## Phase 5: Code Quality Review

After spec compliance passes, review for code quality. Read
`references/review-checklists.md` for the full checklist. This phase catches
issues the spec couldn't anticipate — they emerge from the specific code
written, not from the instructions.

### 5.1 Safety & Correctness

- **Race conditions**: Is there shared mutable state? Are concurrent access
  patterns handled? (Look for: caches, singletons, static fields, shared
  collections accessed from multiple threads or requests)
- **Resource leaks**: Are connections, streams, file handles, and locks
  properly closed? (Look for: try-with-resources in Java, defer in Go,
  context managers in Python, finally blocks)
- **Null safety**: Are values from external sources (database queries, API responses,
  user input) checked before use?
- **Injection safety**: Are all queries and commands parameterized? (No string
  concatenation of user input into queries, commands, or templates)
- **Input validation**: Are all public API inputs validated before processing?
  (Bounds checking, format validation, required fields)

### 5.2 Robustness

- **Error handling**: Do all external calls (database, API, network, file I/O) have
  error handling? Are errors propagated appropriately (not swallowed silently)?
- **Retry logic**: For transient failures (network timeouts, connection resets),
  is there retry logic where appropriate? Is it bounded (max retries, backoff)?
- **Timeouts**: Do outbound HTTP calls have timeouts configured?
- **Edge cases**: Empty collections, zero values, boundary dates, max-length
  strings — are they handled?

### 5.3 Maintainability

- **Hardcoded values**: Are URLs, timeouts, limits, batch sizes, credentials
  externalized to config?
- **Magic numbers**: Are numeric constants named and documented?
- **Dead code**: Any unreachable code paths or unused imports?
- **Consistent patterns**: Does the new code follow the same patterns as the
  existing codebase? (If the spec referenced a pattern file, compare)

### 5.4 Test Quality

- **Coverage**: Does every new public function/method have at least one test?
- **Negative cases**: Are error paths tested? (Invalid input, missing data,
  service unavailable)
- **Assertions**: Do tests assert specific outcomes, not just "no exception"?
- **Tautological test check**: Do tests validate the spec's requirements, or do
  they just assert what the code happens to do? Compare test assertions against
  the spec step's acceptance proof and domain invariants — if the test passes
  but doesn't verify what the spec asked for, it's tautological. This is
  especially common when the implementing agent writes its own tests.
- **Isolation**: Do tests mock external dependencies? Can they run independently?

### 5.5 Optional: AI Architect Consistency Check

If AI Architect MCP is available, optionally run targeted queries to verify
the implementation is consistent with the repo's standards and broader org
patterns. Try pre-analyzed fields first; fall back to code-level tools if
they're empty:

- `getFieldPath(repo, 'coding_standards')` — compare your implementation
  against the repo's pre-analyzed naming, error handling, logging, and
  security patterns. If empty, use `searchCode` to find linter configs and
  compare manually.
- `getFieldPath(repo, 'implementation_patterns')` — verify your code follows
  the repo's standard approaches. If empty, use `searchSymbols` to find
  similar implementations and compare.
- `queryFieldAcrossRepositories` — verify that shared types or interfaces
  this workstream implements match their usage in other repos
- `getFieldPath(repo, 'additional_insights.testing_gaps')` — check if your
  new tests cover known testing gaps

Always cross-check AI Architect results against the locally checked-out code
when available — the index may lag behind recent changes. This is a light
check, not deep exploration. Skip it if the spec's pattern references were
thorough.

### 5.6 Report Findings

Categorize findings as:

- **P0 — Must fix**: Security issues, data corruption risks, race conditions,
  resource leaks. Fix before declaring the workstream complete.
- **P1 — Should fix**: Missing error handling, missing validation, hardcoded
  values. Fix now if quick, otherwise document for follow-up.
- **P2 — Nice to fix**: Style inconsistencies, minor naming issues, additional
  test cases. Document for follow-up.

Fix all P0s. Fix P1s if they take less than 5 minutes each. Document
everything else in the final report.

---

## Phase 6: Final Report

After implementation and both review stages, produce a summary:

```markdown
# Workstream Complete: {WS Name}

**Branch**: `{branch-name}`
**Spec**: `{spec-filename}`
**Status**: Complete | Complete with caveats

## What was built
- {N} files created, {N} files modified
- Key components: {list}

## Verification
- All {N} verification gates passed: ✅
- Spec compliance review: ✅ | ⚠️ {issues}
- Code quality review: ✅ | ⚠️ {issues}

## Spec Deviations (if any)
- Step {N}: {what deviated and why}

## Quality Findings Fixed
- {P0/P1 issues that were fixed during review}

## Open Items (if any)
- {P1/P2 issues documented for follow-up}
- {Spec ambiguities encountered and decisions made}

## Provides Contract Fulfilled
- [ ] {File 1} — created at {path}
- [ ] {File 2} — created at {path}
- [ ] {API endpoint} — implemented
- [ ] {Data entity} — schema matches contract

## Ready for Integration
- [ ] Branch contains only this workstream's changes
- [ ] All tests pass (new + existing)
- [ ] No build warnings or linter errors from new code
```

---

## Execution Notes

1. **One workstream per session.** This skill processes a single agent-spec
   file. To implement multiple workstreams, run multiple sessions (potentially
   in parallel for independent workstreams).

2. **Document decisions.** Any place you made a judgment call the spec didn't
   explicitly cover, add a code comment and include it in the final report.
   This helps during integration review.
