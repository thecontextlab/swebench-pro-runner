# Review Checklists

Read during Phase 4 (Spec Compliance) and Phase 5 (Code Quality).
Clients can replace or extend this file to match their team's standards.

---

## Spec Compliance Checklist

Run after all implementation steps are complete.

### File-Level Checks

For each step in the spec:

- [ ] File exists at the exact path specified
- [ ] File contains the functions/types/components specified
- [ ] Fields, functions, and types match what the spec described
- [ ] Decorators/attributes/metadata match the pattern exemplar referenced
- [ ] Imports are correct and follow the codebase's import ordering convention

### Contract Checks

- [ ] Every entry in the "Provides → Files created" table exists
- [ ] Every entry in the "Provides → Data entities" table has correct schema
- [ ] Every entry in the "Provides → API endpoints" table is implemented and routable
- [ ] Interface signatures match what downstream workstreams expect

### Cross-Cutting Checks

- [ ] Feature flags implemented per the plan (if applicable)
- [ ] Logging added per the plan's observability requirements (if applicable)
- [ ] Error handling follows the plan's stated patterns
- [ ] Changes are rollback-safe per the plan's rollback strategy

### Ownership Boundary

- [ ] Only files listed in the "Owns" section were created or modified
- [ ] No out-of-scope files were touched during implementation or fix attempts
- [ ] Ripple risk files outside the Owns boundary are documented, not modified

### Completeness

- [ ] Every step in the spec was executed
- [ ] All verification gates pass when re-run
- [ ] No unfinished stubs or placeholder implementations (unless explicitly deferred in the spec)
- [ ] Code style matches existing codebase (indentation, naming, formatting)

---

## Code Quality Checklist

Run after spec compliance passes. Organized by severity.

### P0 — Must Fix Before Merge

These issues can cause data loss, security vulnerabilities, or production
incidents. Fix all P0s before declaring the workstream complete.

**Security:**
- [ ] No injection vulnerabilities: all queries and commands use parameterized statements or equivalent
- [ ] No hardcoded credentials, tokens, or secrets
- [ ] Authentication/authorization checks on all new API endpoints
- [ ] Input validation on all public API inputs (type, range, format, length)
- [ ] No path traversal vulnerabilities in file operations
- [ ] Sensitive data not logged (passwords, tokens, PII)

**Data Integrity:**
- [ ] Transactions or atomic operations cover all multi-step writes that must be consistent
- [ ] No race conditions on shared mutable state (caches, counters, singletons)
- [ ] Uniqueness and referential integrity constraints match the schema spec
- [ ] No orphaned or inconsistent data possible from partial failure mid-operation

**Resource Management:**
- [ ] All connections/streams/handles closed (try-with-resources, defer, finally)
- [ ] No unbounded collection growth (e.g., in-memory caches without eviction)
- [ ] Outbound HTTP calls have timeouts configured

### P1 — Should Fix

These issues cause degraded behavior, poor debuggability, or maintenance
headaches. Fix if quick (<5 min each), otherwise document.

**Error Handling:**
- [ ] All external calls (database, API, network, file I/O) have error handling
- [ ] Errors are not swallowed silently (no empty catch blocks)
- [ ] Error messages include enough context to diagnose (which operation, which entity, what input)
- [ ] Retry logic for transient failures is bounded (max retries, backoff)
- [ ] Error responses to callers use appropriate status codes and structured messages

**Null Safety:**
- [ ] Values from database queries checked for null before use
- [ ] Values from API responses checked before dereferencing
- [ ] Optional/nullable fields handled explicitly
- [ ] Collection returns are empty-collection, not null

**Configuration:**
- [ ] URLs, timeouts, batch sizes, and limits externalized to config
- [ ] No magic numbers — numeric constants are named
- [ ] Environment-specific values (dev/staging/prod) are configurable

**Observability:**
- [ ] Key business operations log at INFO level
- [ ] Errors log at ERROR level with stack traces
- [ ] Performance-sensitive operations have timing metrics
- [ ] Batch operations log summary (processed, succeeded, failed)

### P2 — Nice to Fix

These are style and polish issues. Document for follow-up.

**Code Style:**
- [ ] Naming follows codebase conventions
- [ ] Import ordering matches existing files
- [ ] No unused imports or variables
- [ ] No dead code or unreachable paths
- [ ] Comments explain "why" not "what"

**Test Quality:**
- [ ] Every new public function/method has at least one test
- [ ] Error/failure paths are tested (invalid input, missing data, timeouts)
- [ ] Tests assert specific outcomes, not just "no exception thrown"
- [ ] Tests mock external dependencies and can run independently
- [ ] Test names describe the scenario being tested

**Documentation:**
- [ ] Complex logic has inline comments
- [ ] Public API functions have doc comments (using the language's convention)
- [ ] Non-obvious design decisions have comments explaining the choice

---

## Language-Specific Additions

### Java / Spring Boot

- [ ] `@Transactional` on methods that perform multi-step writes
- [ ] `@Valid` on request body parameters
- [ ] Constructor injection (not field injection with `@Autowired`)
- [ ] Proper use of `Optional` for nullable returns
- [ ] Lombok annotations consistent with existing code (@Data, @Builder, etc.)
- [ ] Spring profiles used for environment-specific config

### TypeScript / Angular

- [ ] Strict null checks respected (no `!` non-null assertions without justification)
- [ ] Observables properly unsubscribed (takeUntil, async pipe, or manual unsubscribe)
- [ ] Reactive forms use proper validators
- [ ] Lazy loading configured correctly for new modules
- [ ] TypeScript interfaces defined for all API response shapes

### Go

- [ ] Errors checked and wrapped with context (`fmt.Errorf("operation: %w", err)`)
- [ ] Goroutines have proper lifecycle management (context cancellation)
- [ ] Mutex usage is minimal and well-scoped
- [ ] Defer used for cleanup
- [ ] Exported types and functions have doc comments

### Python

- [ ] Type hints on function signatures
- [ ] Context managers for resource cleanup
- [ ] Exceptions are specific (not bare `except:`)
- [ ] f-strings or `.format()` for string construction (no `%` formatting)
- [ ] Dataclasses or Pydantic models for structured data

---

## How to Use This Checklist

1. **Don't check everything mechanically.** Focus on the sections relevant
   to the code you just wrote. A data loader workstream needs heavy attention
   to data integrity and error handling; a UI scaffolding workstream needs
   more attention to style and component patterns.

2. **Use the severity levels.** P0s are blockers. P1s are judgment calls.
   P2s are polish. Don't hold up a workstream for P2 issues.

3. **The language-specific sections are additive.** Check the general sections
   first, then the language-specific section for the relevant language.

4. **This checklist is a starting point.** Clients should add their own
   team-specific checks (e.g., "all new API endpoints must be documented in
   Swagger," "all new tables must have a created_at column").
