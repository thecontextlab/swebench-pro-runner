# Agent Spec Output Template

Use this template for every workstream agent spec. Adapt section depth to
workstream complexity — a 2-task workstream doesn't need the same depth as
a 10-task one — but never omit sections entirely.

---

```markdown
# Agent Spec: {Ticket-ID} — WS{N}: {Workstream Name}

**Branch**: `{ticket-id}/ws{N}-{slug}`
**Repo(s)**: {list of repos this workstream touches}
**Wave**: {parallelization wave number} — can execute in parallel with: {other WS numbers}
**Estimated steps**: {count}
**Depends on**: {upstream workstream numbers, or "none"}
**Blocks**: {downstream workstream numbers, or "none"}
**Execution mode**: Autonomous — the executor implements every step in this
spec in a single pass without pausing for user confirmation between steps.
Mid-spec interruption is reserved for exhausted-retry failures, unresolvable
ambiguity, or dependency-contract violations.

---

## 0. Context

Before starting, read the full implementation plan for architectural context:
- **Plan document**: `{path or filename of the original implementation plan}`
- **Selected approach**: {1-sentence summary of the approach from the plan}
- **This workstream's role**: {1-sentence description of what this workstream
  delivers within the larger plan}

### Codebase Constraints (apply to ALL steps)

These are always/never rules discovered from the codebase. Follow them in every
file you create or modify:

- {Constraint — e.g., "Import ordering: stdlib → third-party → local"}
- {Constraint — e.g., "Error handling: always wrap with context, never swallow silently"}
- {Constraint — e.g., "Never use deprecated API X, use Y instead"}
- {Constraint — e.g., "Naming: files use kebab-case, types use PascalCase"}
- {Add as many as discovered in Phase 2.4 — these vary by language and project}

---

## 1. Dependency Contract

### Assumes (from prior workstreams or existing codebase)

These artifacts are expected to exist. Do NOT verify their existence — they may
be in a parallel branch. Trust this contract.

**Data entities** (if applicable — tables, collections, schemas, etc.):
| Entity | Key Fields | Source |
|---|---|---|
| `entity_name` | field1 (TYPE), field2 (TYPE), ... | WS{N} or existing |

**Files / interfaces / types** (if applicable):
| File Path | What It Provides | Source |
|---|---|---|
| `exact/path/to/file` | Interface, type, or module description | WS{N} or existing |

**API endpoints** (if applicable):
| Method | Path | Purpose | Source |
|---|---|---|---|
| GET | `/api/path` | Description | WS{N} or existing |

**Config / environment** (if applicable):
| Key | Value / Pattern | Source |
|---|---|---|
| `feature.flag.name` | `true/false` | WS{N} or existing |

### Owns (exclusive files)

Files that ONLY this workstream creates or modifies. No other parallel workstream
touches these — this prevents merge conflicts at integration time.

| File Path | Action (Create / Modify) |
|---|---|
| `exact/path/to/file` | Create |

### Provides (this workstream creates)

Downstream workstreams depend on these. Implement them exactly as specified.

**Files created**:
| File Path | Purpose |
|---|---|
| `exact/path/to/new_file` | Description |

**Data entities** (if applicable — tables, collections, schemas, etc.):
| Entity | Key Fields |
|---|---|
| `new_entity` | field1 (TYPE), field2 (TYPE) |

**API endpoints** (if applicable):
| Method | Path | Purpose |
|---|---|---|
| POST | `/api/new/path` | Description |

---

## 2. Setup

### 2.1 Create branch

```bash
git checkout -b {ticket-id}/ws{N}-{slug} main
```

> **Note:** This skill assumes git branches for workstream isolation. If the team
> uses trunk-based development, replace branching with the team's isolation
> mechanism (e.g., feature flags, workspaces) and adjust the execution manifest's
> integration order accordingly.

### 2.2 Verify starting state

```bash
{project's build command — discovered during Phase 2.3}
{project's test command — discovered during Phase 2.3}
```

Both should pass before proceeding. If they fail, surface the specific errors
to the user — the base branch may have pre-existing issues unrelated to this
workstream. The user decides whether to proceed with known baseline failures.

---

## 3. Implementation Steps

### Step 1: {Short description}

**Action**: Create | Modify | Delete | Configure
**File**: `exact/path/in/repo/filename`
**Pattern**: Follow `exact/path/to/existing_analogue`

**What to implement**:
- {Specific detail — fields, types, framework idioms}
- {Specific detail — function signatures, logic}
- {What to copy from the pattern and what to change}

**Do not modify**: {Files or sections the agent must not touch in this step}

**Ripple risk** (for Modify actions only): {Files outside the direct target that
import, call, or depend on what's being changed — omit for Create actions}

**Domain invariants**: {Business rules the pattern exemplar does NOT encode —
e.g., "all monetary values in cents", "timestamps must be UTC". Omit only if
the step is pure boilerplate with no domain logic.}

**Key decisions** (from the plan):
- {Constraint that eliminates ambiguity}

**Verify**:
```bash
{build or test command from Phase 2.3}
```
**Acceptance proof**: {Concrete evidence — e.g., "file exists at path", "test X passes"}
**Must NOT**: {Negative criteria — e.g., "must not swallow errors silently",
"must not return defaults on failure". Omit only if no plausible failure-masking paths.}

---

### Step 2: {Short description}

**Action**: Create | Modify | Delete | Configure
**File**: `exact/path/in/repo/filename`
**Pattern**: Follow `exact/path/to/existing_analogue`

**What to implement**:
- {Details}

**Do not modify**: {Files or sections the agent must not touch}

**Verify**:
```bash
{command}
```
**Acceptance proof**: {Concrete evidence}
**Must NOT**: {Negative criteria}

---

{Continue for all steps. For workstreams with more than 5 steps, include a
**Context snapshot** at the start of every step after step 5 — a 3-5 line
summary of files created so far, key function/type names, and prior decisions.
This prevents quality degradation as the agent's context window fills up.}

---

## 4. Workstream Verification

After all steps are complete, run the full verification suite:

```bash
# Build the full project/module
{project's full build command}

# Run all tests (existing + new)
{project's full test command}

# Verify no regressions
{any additional checks — lint, format, type-check, etc.}
```

### Expected state after this workstream

- [ ] {N} new files created
- [ ] {N} existing files modified
- [ ] All new tests passing
- [ ] All existing tests still passing
- [ ] No build warnings or linter errors related to new code
- [ ] Branch ready for merge

---

## 5. Post-Implementation Review Checklist

The executor (human or review agent) should verify:

### Spec Compliance
- [ ] Every step in this spec was executed
- [ ] All files exist at the specified paths
- [ ] All verification gates passed
- [ ] The "Provides" contract is fulfilled exactly

### Code Quality
- [ ] Error handling: all external calls (database, API, network, file I/O) use the language's idiomatic error handling
- [ ] Input validation: all public API inputs are validated before processing
- [ ] Null safety: no unguarded access on data from external sources (using the language's idiomatic null-safety patterns)
- [ ] Logging: key operations log at appropriate levels (INFO for business events, ERROR for failures)
- [ ] No hardcoded values that should be configuration (URLs, timeouts, limits, credentials)
- [ ] Thread safety: shared mutable state is properly synchronized (if applicable)
- [ ] Race conditions: concurrent access patterns are identified and handled (if applicable)
- [ ] Injection safety: all external data inputs are sanitized or parameterized before use in queries, commands, or templates
- [ ] Resource cleanup: connections, streams, and handles are closed using the language's idiomatic cleanup pattern
- [ ] Test coverage: new code has unit tests; integration points have integration tests
- [ ] No TODO/FIXME/HACK comments left by the agent (unless the plan explicitly defers something)
- [ ] Follows existing code style (indentation, naming, import ordering)
```

---

## Notes on Using This Template

### Calibrating detail level

**High detail** (include field types, framework idioms, function/method bodies):
- Novel business logic (complex orchestration, multi-step workflows, complex queries)
- Integration points (calling external APIs, event publishing/subscribing)
- Security-sensitive code (auth checks, input validation)
- Complex data transformations

**Medium detail** (describe structure, reference pattern, let agent fill in):
- Standard CRUD operations that closely mirror an existing analogue
- Configuration files that follow an obvious pattern
- Simple data transfer structures or plain data types

**Low detail** (just the file path, pattern reference, and verify command):
- Boilerplate scaffolding (module config, routing setup)
- Test files where the pattern is completely obvious from the source file

### Cross-repo workstreams

When a workstream touches multiple repos, organize steps by repo:

```markdown
## 3. Implementation Steps

### Repo: {first-repo-name}

#### Step 1: ...
#### Step 2: ...

**Verify repo**: `{repo's build command} && {repo's test command}`

### Repo: {second-repo-name}

#### Step 3: ...
#### Step 4: ...

**Verify repo**: `{repo's build command} && {repo's test command}`
```

### Handling ambiguity

If the plan leaves a decision open or there are multiple valid approaches
for a specific step:
1. Check if the plan's "Open Questions" section addresses it
2. If yes, use the "Default" column value
3. If no, pick the approach that's closest to the existing codebase pattern
   and note: "**Decision made in spec**: [what and why]"

Never leave ambiguity for the agent to resolve at implementation time.
