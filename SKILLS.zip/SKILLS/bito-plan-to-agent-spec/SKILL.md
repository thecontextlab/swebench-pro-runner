---
name: bito-plan-to-agent-spec
description: >-
  Transform a technical implementation plan (from bito-scope-to-plan,
  bito-epic-to-plan, or similar) into a set of self-contained, workstream-level
  agent specs — detailed enough that an AI coding agent (Claude Code, Cursor,
  Wingman, or similar) can implement each workstream without interpretation or
  guesswork. Each spec includes exact file paths, pattern references, function
  signatures, verification gates, and a dependency contract.
  Triggers: 'turn this plan into agent specs', 'make this implementable by
  an agent', 'generate coding specs from this plan', 'agent-ready spec',
  'break this plan into agent tasks', 'create agent implementation specs',
  'make this cursor-ready', 'make this claude-code-ready', 'convert plan to
  coding instructions', 'I want an AI to implement this plan'.
  Also trigger when the user provides an implementation plan and wants to
  go from "what to build" to "step-by-step coding instructions an AI agent
  can execute."
---

> **Requires:** The input should be an implementation plan produced by
> `bito-scope-to-plan`, `bito-epic-to-plan`, or a similarly structured document
> containing workstreams, task breakdowns, and architectural decisions.
>
> **Codebase access — use all available sources, verify with local:**
> This skill uses **both** local codebase access and BitoAIArchitect MCP when
> available. Each excels at different things:
>
> - **AI Architect pre-analyzed fields** (`architectural_patterns`,
>   `implementation_patterns`, `coding_standards`, `code_examples`,
>   `module_organization`, `database_schemas`, dependency graphs, clusters) —
>   fast starting points when available. However, these may be incomplete or
>   stale if the repo was recently added or indexing is in progress. Treat them
>   as **accelerators, not the only source**.
> - **AI Architect code-level tools** (`getCode`, `searchCode`, `searchSymbols`,
>   `searchWithinRepository`) — use these to discover information that
>   pre-analyzed fields don't cover, or when pre-analyzed fields are empty.
> - **Local access** — the source of truth for the current state of the code.
>   Always verify AI Architect results locally when the repo is checked out.
>
> **The pattern at every phase:** Try pre-analyzed data first (fast). If empty
> or incomplete, fall back to AI Architect's code-level tools. Always verify
> locally when possible. If only one source is available, the skill can still
> function — surface the limitation to the user at the start of Phase 2.
>
> **Required parameters:** All AI Architect tool calls require `purposeType`
> (use `specification_generation` for this skill) and `purpose` (a specific
> description of what this particular call is for).

> **Customizable:** The output format is driven by `references/output-template.md`.
> Clients can replace this file with their own template to match their team's
> conventions or tooling requirements. The skill's phases and logic stay the same —
> only the spec structure changes.

# Plan-to-Agent-Spec: From Technical Plan to AI-Executable Coding Specs

## Purpose

Take a completed implementation plan — the kind produced by `bito-scope-to-plan`
or `bito-epic-to-plan` — and transform it into a set of **workstream-level agent
specs**. Each spec is a self-contained document with enough detail that an AI
coding agent can implement the workstream start to finish without needing to
interpret ambiguous instructions, explore the codebase for conventions, or make
architectural judgment calls.

**The input plan tells engineers *what* to build and *why*. This skill produces
documents that tell an AI agent *exactly how*, file by file, step by step.**

### What makes an agent spec different from a human plan

A human engineer reading "Create data models for the 5 new entities" knows to look
at existing models, match the project's style, put them in the right directory,
and write tests that follow the team's patterns. An AI agent doesn't have that
institutional knowledge baked in. The agent spec bridges that gap by providing:

- **Exact file paths** — not "create a service" but the full path in the repo
- **Pattern references** — "follow the pattern in `existing_file`, specifically the initialization style, error handling, and any framework-specific idioms"
- **Code-level detail** — field types, function/method signatures, framework idioms, imports
- **Verification gates** — what should build, pass, or be true after each step
- **Dependency contracts** — what files/interfaces exist from prior workstreams (so the agent doesn't need to go exploring)
- **Branch naming** — consistent naming so all workstream branches are traceable

### How this differs from other skills

- **scope-to-plan / epic-to-plan** → produces the plan. This skill *consumes* it.
- **feature-plan** → step-by-step for one engineer. This skill produces specs for *AI agents* across multiple parallel workstreams.
- **TRD** → technical design document for human review. This skill is a *coding instruction set* for machines.

---

## Valid Workflow (State Machine)

```mermaid
flowchart TB
start["START\nReceive Implementation Plan"]
phase1["Phase 1\nParse & Validate Plan\nExtract Workstreams"]
blocked["BLOCKED\nPlan Insufficient\nReport Gaps to User"]
phase2["Phase 2\nCodebase Context Gathering\n(MANDATORY)"]
phase3["Phase 3\nDependency Graph &\nParallelization Strategy"]
checkpoint1["CHECKPOINT 1\nPresent Workstream Graph\n+ Branch Naming\nUser Confirms"]
phase4["Phase 4\nGenerate Agent Specs\n(One Per Workstream)"]
checkpoint2["CHECKPOINT 2\nUser Reviews Specs\n(Spot-check 1-2)"]
phase5["Phase 5\nDeliver Final Specs\n+ Executor Guidance"]
done["DONE\nDeliver Agent Specs"]

start --> phase1
phase1 -- "plan adequate" --> phase2
phase1 -- "critical gaps" --> blocked
blocked -- "user provides missing info" --> phase1
phase2 --> phase3
phase3 --> checkpoint1
checkpoint1 --> phase4
phase4 --> checkpoint2
checkpoint2 -- "specs approved or minor edits" --> phase5
checkpoint2 -- "codebase context wrong" --> phase2
checkpoint2 -- "workstream grouping wrong" --> phase3
phase5 --> done
```

Valid terminal states are `DONE` and `BLOCKED`. Pass through every phase and
checkpoint in order. The `BLOCKED` state is reached when the input plan is
missing critical information that cannot be inferred — surface the specific
gaps to the user and wait for them to provide the missing pieces before
re-entering Phase 1.

---

## Anti-Rationalization Table

| Rationalization | Why It's Wrong |
|---|---|
| "The plan already has enough detail" | Plans describe architecture and acceptance criteria for humans. Agents need file paths, pattern references, and verification commands. The gap is enormous. |
| "I can infer the file paths from the plan" | File paths depend on actual repo structure, package conventions, and module organization. Without querying the codebase, you'll guess wrong. |
| "I'll just add more detail to each task" | Adding detail isn't enough. Agent specs need a fundamentally different structure: ordered steps with contracts, not task tables with AC. |
| "The agent can explore the codebase itself" | Exploration burns context window, introduces inconsistency, and wastes time. The spec should front-load all context the agent needs. |
| "Workstream contracts are overkill — just run them in order" | Sequential execution defeats the purpose. Contracts enable parallel execution, which is the primary value proposition. |
| "The pattern exemplar is enough — the agent will get the business logic right" | Pattern exemplars encode structure, not domain rules. An agent can perfectly copy a handler's shape while violating invariants like "amounts in cents" or "timestamps in UTC." Domain invariants must be stated explicitly per step. |
| "I'll add a 'pause here for review' note between step groups so the user can sanity-check" | The executor runs specs as atomic batches and is explicitly instructed to ignore embedded pauses. If two groups of steps need a human gate between them, they are two workstreams — split them at Phase 3 so the gate becomes a real dependency edge, not a convention the executor will silently violate. |

---

## Phase 1: Parse & Validate the Plan

Read the input plan and extract:

1. **Workstreams** — see below for how to identify or synthesize these
2. **Cross-cutting concerns** — rollback strategy, feature flags, observability (these inform every spec)
3. **Selected approach** — the architectural decisions that constrain implementation
4. **Schema definitions** — any data schemas (SQL, NoSQL, GraphQL, protobuf, etc.), API contracts, or data models (these are shared context)
5. **Domain invariants** — business rules embedded in the plan's acceptance criteria,
   data model notes, or requirements that constrain how code must behave (e.g.,
   "amounts stored in cents", "timestamps always UTC", "tenant-scoped uniqueness").
   Extract these explicitly — they will be distributed to the relevant steps in
   Phase 4 so the executing agent enforces them even when the pattern exemplar
   doesn't encode them.
6. **Sequencing & critical path** — which workstreams block which

### 1.1 Identifying Workstreams

Plans from `bito-scope-to-plan` and `bito-epic-to-plan` already organize work
into named workstreams. Use those directly.

If the input plan does **not** have explicit workstreams (e.g., a flat task list,
a plan organized by repo, by feature area, or by sprint), you need to synthesize
workstreams before proceeding. Group tasks into workstreams using these criteria:

- **Cohesion**: tasks that touch the same files, data entities, or modules belong together
- **Isolation**: a workstream should be implementable in its own branch without
  conflicting with other workstreams' file changes. If two groups both modify
  the same file, they should be in the same workstream (or sequenced, not parallel)
- **Reasonable size**: each workstream should be 2-8 tasks — small enough for one
  agent session's context window, large enough to be a coherent unit of work
- **Clear dependencies**: the grouping should make the dependency graph between
  workstreams simple (ideally a DAG, not a tangle)

Name each synthesized workstream with a short descriptive label
(e.g., "Data Model", "Core APIs", "UI Wizard") and assign a workstream number
for ordering and branch naming.

**Splitting oversized workstreams:** If an identified or synthesized workstream
has more than 8 steps, split it. Use these criteria:

- **Natural seams**: Look for a point where the workstream produces an
  intermediate artifact (e.g., schema done → service layer starts). Split there.
- **Layer boundaries**: Split by architectural layer — e.g., "WS1a: Schema
  Migration" and "WS1b: Data Access Layer" — when the lower layer is a
  prerequisite for the upper layer.
- **Same-branch splitting**: If the two halves must be sequential and touch the
  same files, they can share a branch (WS1a merges, WS1b branches from it) — but
  each still gets its own agent spec file so a single agent session doesn't exceed
  its context window.

A workstream with more than ~12 steps risks overflowing a typical agent context
window mid-implementation, causing quality degradation. Prefer splitting over
generating an oversized spec.

**Splitting at human-review seams:** If the plan calls for explicit human
review or approval between two groups of steps (e.g., "review migration before
applying data backfill"), split the workstream at that seam into two specs.
The executor runs each spec autonomously — do NOT embed "pause for review"
checkpoints inside a single spec, because the executor is instructed to
ignore them. The seam becomes a dependency edge in Phase 3's graph instead.

Present synthesized workstreams to the user at Checkpoint 1 for confirmation
before generating specs.

### 1.2 Validation

Validate that the plan has enough information to generate specs:
- Each workstream (identified or synthesized) should have tasks with acceptance criteria
- There should be a clear dependency graph (even if implicit)
- The selected approach should be specific enough to constrain file organization

If the plan is missing critical information (e.g., no schema definitions, no repo names), surface this to the user before proceeding.

---

## Phase 2: Deep Codebase Exploration (MANDATORY — DO NOT SKIP)

Before writing any spec, build a concrete understanding of the actual codebase.
The agent specs must reference real file paths, real patterns, and real
conventions — not guesses. This is the most important phase of the skill — the
quality of the agent specs is directly proportional to the depth of codebase
exploration done here.

### Relationship to upstream exploration

The input plan (whether from `bito-epic-to-plan`, `bito-scope-to-plan`, or
created manually) may already include codebase exploration — repos identified,
service topology, data models, existing analogues, and integration points. That
exploration answered "what does this system look like?" This phase goes deeper
and answers a different question: **"what exact files, patterns, and conventions
should the agent copy?"**

Treat the plan's exploration findings as a starting point, not a substitute.
The plan says "the X creation flow is the closest analogue."
This phase traces that analogue to find the exact source files, their structural
idioms, their test files, their data transfer structures — the concrete details
an agent needs to replicate the pattern.

### Exploration approach

Start by calling AI Architect's `getCapabilities` to confirm the MCP server is
available. Then call `listRepositories` or `searchRepositories` to resolve the
repo names from the plan to actual AI Architect identifiers. Optionally call
`listClusters` to see which repos are grouped together by dependency
relationships — this helps identify related repos that the plan might not
mention but that could be affected by the changes.

AI Architect provides **pre-analyzed data** that would take hours to derive
manually — including `architectural_patterns`, `implementation_patterns`,
`coding_standards`, `code_examples`, `module_organization`, and
`database_schemas`. Use `getFieldPath` for surgical extraction of specific
fields (95-99% data reduction vs full fetches). Supplement with local file
reads for the latest content. Explore these categories:

| epic-to-plan explored... | This phase goes further to find... |
|---|---|
| Service topology & repos affected | Exact directory structure per repo: where each layer of the codebase lives (the actual directory names and nesting — these vary by language and framework) |
| Data model & schema | Exact migration/schema file patterns and conventions used in this project |
| Closest existing analogue | The full file chain for one complete feature — from entry point through business logic, data layer, and tests — with exact paths |
| Integration points | Exact client modules or components, how dependencies are wired, how errors are handled |
| Architectural health & landmines | Specific patterns to avoid or work around in the agent specs |

### 2.1 Discover the Stack and Gather Per-Repo Context

**Before looking at any specific files, identify the language, framework, and
toolchain for each repo.** Try these sources in order:

1. **Pre-analyzed fields** (fast, when available):
   - `getFieldPath(repo, 'project_overview')` → primary languages, frameworks, architecture summary
   - `getFieldPath(repo, 'module_organization')` → package structure, layer boundaries, init patterns
   - `getFieldPath(repo, 'repository_structure')` → directories, config files, is_monorepo
2. **AI Architect code-level tools** (if pre-analyzed fields are empty or incomplete):
   - `getRepositoryInfo(repo, detailLevel: 'summary')` for an overview
   - `searchWithinRepository` for build configs, README, project root files
3. **Local inspection** (always, when repo is checked out):
   - Read build config files, README, and project root locally to verify
     and supplement what AI Architect returned

This discovery step determines the vocabulary for the rest of the spec —
different stacks organize code differently and use different terminology.

Then, for each repo, use AI Architect (`searchSymbols`, `searchCode`,
`searchWithinRepository`) for targeted discovery, and local file reads for the
latest content. Discover:

- **Directory structure** — the project's actual layout: where source files,
  tests, configuration, and migrations live. Don't assume a standard layout;
  discover it from the repo. Every stack organizes differently.
- **Naming conventions** — how files, types, functions, and variables are named
  in this specific codebase
- **Existing analogues** — the closest existing feature to what each workstream
  builds (the plan usually identifies this; verify and get specific file paths)
- **Framework idioms** — how dependencies are wired, how the data access layer
  is used, how the test framework is configured, what the build tool expects.
  Discover these from actual code, not from assumptions about the stack.
- **Import/module conventions** — how files reference each other

If the plan identifies a "closest existing analogue," use AI Architect to trace
that analogue end-to-end: find the entry point, business logic, data access,
data transfer structures, and test files. These become the pattern exemplars in
the next step.

### 2.2 Capture Pattern Exemplars

Try these sources in order:

1. **Pre-analyzed patterns** (fast, when available):
   - `getFieldPath(repo, 'implementation_patterns')` → task-level patterns with
     standard_approach, code_example, libraries_used, and file locations
   - `getFieldPath(repo, 'code_examples')` → pre-extracted canonical code snippets
     for common patterns (handlers, transactions, middleware, retry, etc.)
   - `getFieldPath(repo, 'architectural_patterns')` → named patterns with
     confidence scores, descriptions, and evidence
2. **AI Architect code-level tools** (if pre-analyzed fields are empty, or to
   find exemplars for specific artifact types not covered by pre-analyzed data):
   - `searchSymbols` to find existing implementations of the artifact type
   - `getCode` to read the full file for a candidate exemplar
3. **Local file reads** (always, when repo is checked out):
   - Read the actual exemplar files locally to confirm patterns are current
   - AI Architect's indexed code may be behind recent refactors

For each type of artifact the specs will ask the agent to create, find ONE
concrete example in the codebase that represents the canonical pattern. The
artifact types depend on the stack — discover them from the codebase rather than
assuming a fixed taxonomy. Common categories include entry points/handlers,
business logic modules, data access/repository layers, data transfer structures,
test files, and migration/schema files — but the actual names and shapes vary.

Record for each exemplar:

- The exact file path
- The key structural elements (framework idioms, base types, initialization patterns)
- The test file that covers it (if any)
- Key code patterns the agent should replicate (e.g., how errors are wrapped,
  how transactions or middleware are applied, how dependencies are provided)

These become the "follow this pattern" references in the agent specs. This is
where the agent spec gets its power — instead of "create a handler," the spec
says "create a handler following the pattern in `path/to/existing_handler`,
specifically the dependency setup at line N, the middleware usage at line M,
and the error handling pattern at line P."

**Guarding against exemplar overfitting:** Pattern exemplars often contain
incidental complexity — deprecated API calls, workarounds for old bugs, or
patterns that were correct for that file's specific context but wrong for the
new one. When recording exemplars, explicitly note what to copy (structural
patterns, framework idioms, error handling style) and what to ignore (any
deprecated APIs, context-specific workarounds, or legacy patterns). Include
these "do not copy" notes in the spec step alongside the pattern reference.

### 2.3 Capture Build & Verification Commands

For each repo, determine the **actual** commands used in that project:

- How to compile/build (discover from build config files, CI config, or README)
- How to run all tests
- How to run a specific test file or test case
- How to lint or format check
- Any pre-commit hooks or CI checks that must pass

**Discover these from the repo itself** — look at `Makefile`, `package.json`
scripts, CI config (`.github/workflows/`, `Jenkinsfile`, `.gitlab-ci.yml`),
`README.md`, or equivalent. Do not assume standard commands; many projects have
custom build scripts, monorepo tooling, or wrapper commands.

These become the verification gates in the agent specs.

### 2.4 Capture Codebase Constraints

Discover the always/never rules that govern this codebase — the conventions an
agent must follow within every file it touches. These are different from pattern
exemplars (which show *how* to structure a file) — constraints are guardrails
that apply across all files regardless of pattern.

Try these sources in order:

1. **Pre-analyzed standards** (fast, when available):
   - `getFieldPath(repo, 'coding_standards')` → naming, error handling, logging,
     concurrency, database patterns, design patterns, testing, security
   - `getFieldPath(repo, 'coding_standards.code_style')` → specific style rules
   - `getFieldPath(repo, 'additional_insights.error_handling_strategy')` →
     per-category error handling patterns
2. **AI Architect code-level tools** (if pre-analyzed fields are empty):
   - `searchCode` to find linter configs, CI check definitions, contributing guides
   - `getCode` to read the actual config files
3. **Local reads** (always, when repo is checked out):
   - Read linter configs (`.eslintrc`, `pyproject.toml`, `.golangci.yml`, etc.)
     and CI definitions locally for the latest rules

Examples of constraints to extract:

- Import ordering conventions (stdlib first, then third-party, then local)
- Naming rules (always use camelCase for variables, PascalCase for types)
- Prohibited patterns (never use wildcard imports, never use deprecated APIs)
- Error handling conventions (always wrap errors with context, never swallow errors silently)
- Test conventions (always co-locate test files, always use a specific assertion library)

These constraints go into each spec's preamble so the agent applies them
consistently.

### 2.5 Discover Ripple Risks for Modified Files

For any existing file the plan intends to modify (not create), discover what
depends on it at two levels:

**Service-level ripple:** Use AI Architect's `getFieldPath(repo,
'incoming_dependencies')` to find other services that depend on this repo.
If the change affects an API endpoint or shared interface, downstream services
may break.

**File-level ripple:** Use AI Architect (`searchSymbols`, `searchCode`,
`searchWithinRepository`) and the platform's local search tools together. Use
`searchSymbols` for code-level references (imports, function calls),
`searchCode` for string-level references (config files, documentation, YAML),
and local search for the latest state of any discovered dependencies:

- Files that import or reference the file being modified
- Functions or types from this file that are called elsewhere
- Config or registration files that wire this file into the system

Record these as ripple risks. They go into the Modify step's "Ripple risk" field
so the executing agent knows which files to check after making changes. Without
this, the agent modifies a file and has no idea what broke downstream.

### 2.6 Identify Shared Context

Extract concrete details that multiple workstream specs will reference.
Try these sources in order:

1. **Pre-analyzed data** (fast, when available):
   - `getFieldPath(repo, 'database_schemas')` → tables, columns, relationships,
     access patterns
   - `getFieldPath(repo, 'additional_insights.external_integrations')` → databases,
     message queues, dependent microservices
   - `getFieldPath(repo, 'cross_references.symbols')` → symbol-level cross-references
2. **AI Architect code-level tools** (if pre-analyzed fields are empty):
   - `searchCode` to find schema files, API definitions, shared type files
   - `getCode` to read them
3. **Plan + local verification** (always):

- Data entity names and field types — tables, collections, document schemas, etc. (from the plan's schema section)
- API endpoint paths and request/response shapes
- Shared types, interfaces, or data structures that cross workstream boundaries
- Config/environment variable names
- Feature flag names and their expected behavior

For multi-repo plans, use AI Architect's `queryFieldAcrossRepositories` to
verify that shared types and interfaces the plan references actually exist and
have the expected shape. The plan may describe cross-repo contracts that have
since changed — ground-truth them against the codebase (locally when possible,
via AI Architect for repos without local access).

---

## Phase 3: Dependency Graph & Parallelization Strategy

### 3.1 Build the Workstream Dependency Graph

From the plan's sequencing section and task dependencies, build an explicit graph:

```
WS1 (Data Schema) ──→ WS3 (Core APIs) ──→ WS7 (Integration Wiring)
                ├──→ WS2 (Data Loader) ──→ WS4 (Search)
                └──→ WS5 (External API)
WS6 (UI) ──────────→ (depends on WS3, WS4, WS5 APIs being defined, not implemented)
WS8 (Background Jobs) → (depends on WS1 schema)
```

### 3.2 Identify Parallelizable Groups

Group workstreams that can execute simultaneously:

- **Wave 1**: Workstreams with no dependencies (usually data schema, scaffolding)
- **Wave 2**: Workstreams that depend only on Wave 1
- **Wave 3**: Workstreams that depend on Wave 2
- etc.

### 3.3 Define Branch Naming Convention

Branch names must be consistent, traceable, and work across repos. Convention:

```
{ticket-id}/ws{number}-{slug}
```

Examples:
- `PROJ-100/ws1-data-model`
- `PROJ-100/ws3-core-apis`
- `PROJ-100/ws6-admin-wizard`

Rules:
- **Ticket ID** comes from the plan's epic/story ID. If no ticket ID exists, use a short project slug (e.g., `myproject/ws1-data-model`).
- **Workstream number** preserves ordering from the original plan.
- **Slug** is a 2-4 word kebab-case summary of the workstream.
- Same convention applies whether branches are in the same repo or different repos.

### 3.4 Define Dependency Contracts

For each workstream, define THREE things:

**Assumes (inputs):** What this workstream expects to already exist. Be specific:
- Exact data entity names with field names and types (tables, collections, schemas, etc.)
- Exact file paths for interfaces, types, or modules it depends on
- Exact API endpoint paths it will call

**Provides (outputs):** What this workstream will create that downstream workstreams depend on:
- Files created (with paths)
- Data entities created (tables, collections, schemas, etc.)
- API endpoints available
- Interfaces or types defined

**Owns (exclusive files):** Files that ONLY this workstream creates or modifies.
No other parallel workstream should touch these files. This prevents merge
conflicts when branches are integrated. If two workstreams must modify the same
file, they cannot be parallel — sequence them or merge them into one workstream.

The "Assumes" section is baked into each spec's preamble. The agent reads it and
trusts it as ground truth — it doesn't verify these things exist because they may
be in a parallel branch. If the upstream workstream deviated from the contract,
that gets caught at integration time (when branches merge).

---

## CHECKPOINT 1: Present to User

Present:
1. The workstream dependency graph (visual)
2. The parallelization waves
3. The branch naming convention with examples for this project
4. The dependency contracts (summarized — full detail goes in the specs)

Ask: "Does this grouping and sequencing make sense? Any workstreams you want to merge or split? Is the branch naming convention right for your team?"

---

## Phase 4: Generate Agent Specs

Generate one spec file per workstream. Read `references/output-template.md` for
the exact structure to follow. This template is the primary customization point —
clients can replace it with their own format while keeping the rest of the skill
unchanged. If a custom template exists, use it; otherwise use the default.

### Key Principles

**Self-contained**: Each spec includes everything the agent needs. No external
references except the original plan (which is included as top-level context).

**Ordered steps, not task tables**: Replace the plan's task table with a numbered
sequence of steps. Each step produces a specific file or change. Steps are ordered
so that each one builds on the prior (the agent can verify after each step).

**Pattern-first**: Every step that creates a new file starts with "Follow the
pattern in [existing file]." The agent should be copying and adapting, not
inventing from scratch.

**Verify after every logical unit**: After creating a data model + its data
access layer, run the project's build or check command. After creating a service
module, run the relevant tests. Don't wait until the end of the workstream to
verify.

**Include the original plan**: The spec should instruct the agent to read the
original implementation plan document for high-level context and architectural
intent. This gives the agent the "why" behind the instructions.

**Atomic workstream**: The generated spec represents one indivisible unit of
work. The executor will implement every step in a single pass without pausing
for user confirmation between steps. Do not write steps in a way that implies
natural "checkpoints" for the user — avoid phrasing like "once this is
approved, continue to...", "pause here for review", or "confirm before
proceeding to step N+1". If a workstream genuinely needs mid-stream human
review, that's a signal to split it into two workstreams at Phase 3, not to
embed a pause inside one spec.

### Per-Step Detail Level

Each step in the spec should include:

```markdown
### Step N: [Short description]

**Action**: Create | Modify | Delete | Configure
**File**: `exact/path/to/filename`
**Pattern**: Follow `exact/path/to/existing_analogue`

**What to implement**:
- [Specific field, function, or change — enough detail that the agent
  doesn't need to make judgment calls]
- [Include types, function signatures, framework idioms]
- [If modifying, specify what to add/change and what to leave alone]

**Do not modify**: [List any files or sections the agent must not touch in this
step — prevents scope creep into adjacent code]

**Ripple risk** (for Modify actions): [List files outside the direct target that
import, call, or depend on what's being changed — these may need updates too.
Omit for Create actions where nothing depends on the new file yet.]

**Domain invariants**: [Business rules the pattern exemplar does NOT encode but
this step must respect — e.g., "all monetary values in cents, not dollars",
"timestamps must be UTC", "this field is unique per tenant, not globally".
Omit only if the step is pure boilerplate with no domain logic.]

**Key decisions already made**:
- [Architectural choice from the plan that constrains this step]

**Verify**: `{build/test command discovered in Phase 2.3}` passes
**Acceptance proof**: [Concrete evidence of completion — e.g., "file exists at
path", "test X passes", "endpoint returns 200" — not just "step done"]
**Must NOT**: [Negative criteria — e.g., "must not swallow errors silently",
"must not return default/empty values on failure", "must not bypass validation".
Omit only if there are no plausible failure-masking paths.]
```

The level of detail should be calibrated: boilerplate steps (creating a standard
CRUD entity that matches an existing pattern exactly) can be briefer. Steps
involving novel logic, complex queries, or integration with external services need
more detail.

### Context Snapshots for Long Workstreams

For workstreams with more than 5 steps, include a **context snapshot** at the
start of every step after step 5. This is a compressed summary (3-5 lines) of
what has been created so far — file paths, key function/type names, and any
decisions made in prior steps. Agent quality degrades sharply around steps 8-12
as accumulated context exceeds what the agent can reliably hold. The snapshot
lets each step be understood semi-independently, even if the agent's memory of
early steps has degraded.

### Handling Cross-Repo Workstreams

If a workstream touches multiple repos:
- Group steps by repo
- Include repo-switch instructions: "Switch to repo `{repo-name}`"
- Each repo section gets its own verification gates
- The branch name is the same across repos (e.g., `TICKET-ID/ws8-integration`)

### Output File Naming

```
{ticket-id}-ws{number}-{slug}.agent-spec.md
```

Examples:
- `PROJ-100-ws1-data-model.agent-spec.md`
- `PROJ-100-ws3-core-apis.agent-spec.md`

---

## CHECKPOINT 2: User Reviews

Present the first 1-2 specs (pick the most complex or most critical workstream)
for user review. Ask:

- "Is this the right level of detail for your agent tooling?"
- "Are there any patterns or conventions I got wrong?"
- "Does the verification approach work for your setup?"

### Handling Feedback

- **Minor edits** (detail level, wording, missing fields): Apply feedback to all
  specs and proceed to Phase 5.
- **Codebase context is wrong** (wrong file paths, wrong patterns, wrong build
  commands): Return to Phase 2 to re-explore the specific areas the user flagged.
  Then regenerate the affected specs (Phase 4) and re-present at this checkpoint.
- **Workstream grouping is wrong** (should merge/split workstreams): Return to
  Phase 3 to restructure the dependency graph, then regenerate specs.

Always apply feedback globally — if the user corrects a convention in one spec,
fix it in all specs that share the same pattern.

---

## Phase 5: Deliver Final Specs + Execution Manifest

### 5.1 Deliver the Spec Files

Save all specs to the output directory. Each is a standalone markdown file.

### 5.2 Generate the Execution Manifest

Create a `{ticket-id}-execution-manifest.md` that summarizes:

1. **All specs** — filename, workstream, repo(s), estimated complexity
2. **Execution waves** — which specs can run in parallel
3. **Branch naming** — the convention and all branch names
4. **Integration order** — after all specs execute, what order to merge branches
5. **Post-merge verification** — what tests to run after merging all branches

### 5.3 Execution Guidance

Each spec is a self-contained markdown file that can be consumed by any AI
coding agent directly. If `bito-agent-spec-executor` is available, it provides
structured step-by-step implementation with verification gates and two-stage
review. If not, any agent can follow the spec's sections in order — the
instructions are explicit enough to execute without a dedicated executor skill.
The manifest should note:

- Each spec should be fed to one agent session along with the original
  implementation plan
- Specs in the same parallelization wave can be executed simultaneously in
  separate sessions
- The executor skill is platform-agnostic — it works with any agentic coding
  platform that supports skill-based execution, or can be followed manually
- After all workstreams complete, merge branches following the integration
  order in this manifest

---

## Quality Checklist for Generated Specs

Before delivering, verify each spec against these criteria:

- [ ] Every step has an exact file path (no placeholders like "appropriate directory")
- [ ] Every new file references a pattern exemplar from the codebase
- [ ] Every step has a verification gate with concrete acceptance proof
- [ ] Every step has a "Do not modify" boundary (or explicitly states "none")
- [ ] Steps that modify existing files include a ripple risk assessment
- [ ] The preamble contract lists exact entity/file/interface dependencies
- [ ] The preamble includes codebase constraints (always/never rules) discovered in Phase 2.4
- [ ] The "Owns" section lists all files exclusively touched by this workstream
- [ ] No two parallel workstreams claim ownership of the same file
- [ ] The branch name follows the convention
- [ ] Cross-cutting concerns (logging, error handling, feature flags) are addressed in relevant steps
- [ ] Steps with domain logic include domain invariants (business rules the exemplar doesn't encode)
- [ ] Steps with error-handling or external calls include "Must NOT" negative criteria
- [ ] Pattern references note what to copy and what to ignore (no exemplar overfitting)
- [ ] No step requires the agent to make an architectural judgment call
- [ ] The spec can be understood without reading other workstream specs
- [ ] Workstreams with more than 5 steps include context snapshots starting at step 6
- [ ] All terminology is derived from the discovered codebase (no assumed language or framework vocabulary)
- [ ] No step's instructions, acceptance proof, or "Must NOT" wording implies the agent should stop and wait for user confirmation before proceeding to the next step
